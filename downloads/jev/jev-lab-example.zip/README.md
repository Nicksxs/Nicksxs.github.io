# Jev 小实验

用 TypeSafe 官方 JavaScript SDK 同时问三个独立问题：把合成客服工单送到哪个处理入口（Choice）、有多紧急（Score）、是否明确要求退款（Noul）。只输出建议，不创建真实工单、不执行退款。Jev 是远程 API 模型；安装 skill 或 SDK 不等于下载了可离线运行的模型。

需要 Node.js 20+。本目录的依赖单独锁定为 `@typesafe-ai/sdk@0.6.0`，不改博客依赖。

```bash
cd tools/jev-lab
npm install --ignore-scripts --no-audit --no-fund --registry=https://registry.npmjs.org
node index.mjs
```

默认是 `--dry-run`：显示将要发送的 state、问题和模型；不读密钥、不联网、不伪造答案。查看六条输入：

```bash
node index.mjs --dry-run --suite
```

## 调用真实 API

从 [TypeSafe 控制台](https://console.typesafe.ai/) 获取 API key，通过本机编辑器把 key 单独保存到 `~/.config/nicksxs/typesafe-api-key`，建议将文件权限设为 `600`。不要把 key 发到对话、写进源码或提交 Git。也可以在自己的终端设置 `TYPESAFE_API_KEY`，或通过 `--key-file PATH` 指定本地文件。明确指定的文件优先于环境变量。

```bash
# 一次请求，使用视频里的中文“我被扣了两次钱，请今天退回多扣的一笔。”
node index.mjs --run

# 六次顺序请求：中英文退款、中英文“不要退款”、信息模糊、无关内容
node index.mjs --suite

# 固定具体模型版本时，用控制台 / 官方模型列表中确实可用的名称
node index.mjs --run --model jev-latest --key-file /absolute/path/to/key
```

真实调用可能消耗账号额度。端点固定为 `https://api.typesafe.ai`，每次超时 15 秒，重试次数为 0；服务错误会结束本次运行，避免继续发送剩余用例。没有可用 key 会在请求前退出。

真实运行会在本目录 `results/` 写入带 UTC 时间和随机 ID 的 JSON 文件。每条记录包含实际 wall-clock 延迟、请求、服务返回的模型名、token usage、完整 answers 和展示用建议；不记录 key、请求头或原始 SDK 错误。文件不会覆盖已有运行记录，`results/` 已被 Git 忽略。`jev-latest` 会随官方更新，记录中的 `model` 用于追溯实际返回的版本。

## 怎样读结果

`route` 从 `refund / support / other` 中选一个入口。这里的 `refund` 只是“退款相关入口”，不表示已经核实交易、满足退款规则或获得执行授权。

`urgency` 的四个等级是具体情景，分值范围 0–3；小数是各等级编号按返回概率加权的结果。它不是“故障概率”或“影响了多少用户”。`explicit_refund.noul` 是“明确要求退款”这一命题为真的概率，接近 0.5 表示 yes/no 相近，不代表退款意愿程度中等。

示例代码在 Choice confidence 小于 0.8、退款概率落在 0.2–0.8 之间，或两个独立判断冲突时显示 `human_review`，否则显示 `route` 建议。这些阈值没有用真实客服数据校准，只用于体验概率怎样参与代码分支。Score 在这里保留供阅读，不用于自动行动；高 confidence 也不保证事实正确。三道问题在同一次 API 调用中提交，它们看不到彼此的答案。

延迟从 SDK 调用前量到响应解析完成，包括网络、连接建立和服务耗时；无预热、无重试，六条输入顺序执行。它不是模型纯推理时间，也不能拿几次样例证明“比某个大模型快多少”。所有输入都是人工编写的合成案例，不是准确率评测集。

## 参考

- [官方 agent skill](https://github.com/typesafe-ai/skills/tree/main/skills/typesafe-ai)
- [JavaScript SDK](https://docs.typesafe.ai/sdk/javascript)
- [Choice](https://docs.typesafe.ai/primitives/choice)、[Score](https://docs.typesafe.ai/primitives/score)、[Noul](https://docs.typesafe.ai/primitives/noul)
- [Confidence 的含义](https://docs.typesafe.ai/confidence)
- [函数调用 cookbook](https://docs.typesafe.ai/cookbooks/function_calling)

接口依据：2026-09-20 阅读的官方文档与 SDK 0.6.0 类型定义。

## 已完成的首次体验

2026-09-20 已对六条合成输入发出真实请求，均成功返回 `jev-1.13.0`。首条本机耗时 1962.02 ms，随后五条为 744.75–823.44 ms；没有比较其他模型，也不能据此断言首次较慢的原因。中英文退款样本的 `explicit_refund.noul` 均为 0.99，两条明确否定退款的样本均为 0.03；模糊中文工单的 route confidence 为 0.54，进入示例人工复核分支。

完整实验快照在博客源码中保存在 `source/downloads/jev/jev-smoke-test-2026-09-20.json`，下载示例包也附带同名 JSON。测试用例标签没有进入 `state`，避免把测试意图泄漏给模型。此样本只验证接口与基本行为，不是准确率或概率校准评测。

Skill 安装到本项目 `.agents/skills/typesafe-ai/`，Codex 下一轮可加载。由于直接 Git 传输失败，使用官方仓库归档再经 `npx skills add` 安装；来源与哈希见 `installation.json`。`skills-lock.json` 记录官方仓库来源，避免更新依赖临时目录。
