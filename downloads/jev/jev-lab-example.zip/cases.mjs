// These are synthetic inputs, not customer records or recorded model answers.
export const cases = [
  {
    id: 'zh-double-charge',
    language: 'zh',
    text: '我被扣了两次钱，请今天退回多扣的一笔。',
  },
  {
    id: 'en-double-charge',
    language: 'en',
    text: 'I was charged twice for one order. Please refund the duplicate charge today.',
  },
  {
    id: 'zh-not-a-refund',
    language: 'zh',
    text: '我不是来申请退款的，不要退款。我只是想知道发票在哪里下载。',
  },
  {
    id: 'en-not-a-refund',
    language: 'en',
    text: 'I do not want a refund. Please help me reset my password; I can still use my existing session.',
  },
  {
    id: 'zh-ambiguous',
    language: 'zh',
    text: '昨天那个事情，能不能帮我处理一下？我也不确定该怎么办。',
  },
  {
    id: 'en-unrelated',
    language: 'en',
    text: 'Tell me a funny story about a penguin learning to fly.',
  },
];
